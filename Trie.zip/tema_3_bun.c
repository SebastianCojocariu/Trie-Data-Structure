#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct celula_trie
{   int sfarsit_cuvant; //0 pentru nu,1 pentru da
    char litera;
    int nr_fii;
    struct celula_trie *parinte;
    struct celula_trie **fii;

}TCelula;

typedef struct trie
{
  TCelula *celula;

}Trie;


TCelula *Aloca_Celula()
{
  TCelula *celula = malloc(sizeof(TCelula));
  celula->nr_fii = 0;
  celula->parinte = malloc(sizeof(TCelula));
  celula->parinte = NULL;
  celula->sfarsit_cuvant = 0;
  celula->fii= malloc(sizeof(TCelula*));
  *celula->fii = malloc(sizeof(TCelula));
  *celula->fii = NULL;
  return celula;
}

void Init_Trie(Trie *trie)
{
  trie->celula = Aloca_Celula();
  trie->celula->litera = '\0';

}




void distruge(TCelula *celula)
{
    if(!celula) return;
    if(celula->nr_fii == 0)
    {
      free(celula -> fii);
      *celula->fii = NULL;
      free(celula->parinte);
      celula->parinte = NULL;
      free(celula);

      //celula=NULL;
    }
    int i;
    for(i=0 ; i<celula->nr_fii;i++)
    distruge(celula->fii[i]);
    celula->parinte = NULL;
    *celula->fii = NULL;
    free(celula);

}


void DISTRUGE(TCelula **celula)
{
  if(*celula == NULL) return;
  distruge(*celula);
  *celula = NULL;
}


//functie de insert care insereaza un string in trie
void Insert(Trie *trie,char *string)
{
  //daca cuvantul e null se iese din functie
  if(!string) return;
  TCelula *aux = trie->celula;
  int  i=0,count=0;

  //parcurgem trie-ul in functie de cuvantul dat litera cu litera pana cand intalnim
  //o litera care nu e in trie
  while(string[count] != '\0'&& i<aux->nr_fii)
  {

    if(aux->fii[i]->litera == string[count])
    {
      aux = aux->fii[i];
      count++;
      i=0;

    }
    else
      i++;

    }
//daca am ajuns la sfarsit de cuvant marcam cu 1 la sfarsit si iesim din functie
  if(string[count] == '\0')
  {
     aux->sfarsit_cuvant = 1;
     return;
  }

//daca au ramas litere ,creem celule pentru fiecare astfel de litera si facem legaturile
  while(string[count] != '\0')
  {



      TCelula *celula = Aloca_Celula();
      celula->litera = string[count];
      aux->nr_fii++;
      celula->parinte = aux;

      aux->fii=realloc(aux->fii,(aux->nr_fii)*sizeof(TCelula*));
      TCelula *celula_auxiliara_sort = Aloca_Celula();

      aux->fii[aux->nr_fii-1] = celula;
      int i,j;

      //sortam alfabetic vectorul de fii dupa litera
      for(i=0 ; i<aux->nr_fii-1 ; i++)
      {
        for( j=i+1 ; j<aux->nr_fii ; j++)
        {
          if(aux->fii[i]->litera > aux->fii[j]->litera)
           {
           celula_auxiliara_sort = aux->fii[i];
           aux->fii[i] = aux->fii[j];
           aux->fii[j] = celula_auxiliara_sort;
          }
        }
      }
      aux = celula;
      count++;

  }
  aux->sfarsit_cuvant = 1;

}

//functie care returneaza celula de sfarsit al unui prefix primit ca parametru
//sau NULL daca nu a gasit prefixul

TCelula *find_prefix(Trie *trie,char *prefix)
{
  if(!prefix || !trie || !trie->celula)
    return NULL;


  TCelula *aux = trie->celula;
  int i=0,count=0;

//parcurgem litera cu litera prefixul dat si cautam drumul corect
  while(prefix[count] != '\0' && i<aux->nr_fii)
  {

    if(aux->fii[i]->litera == prefix[count])
    {
      aux = aux->fii[i];
      count++;
      i = 0;
    }
    else
      i++;

  }
  if(prefix[count] == '\0')
    return aux;
  return NULL;

}


//functie care afiseaza cuvintele existente in trie de la o celula anume
//vom folosi functia in celelalte functii care  urmeaza

void afisare_cuvinte_de_la_o_celula_anume(FILE *out,TCelula *a,char *cuvant,int dimensiune)

{
  dimensiune = dimensiune+1;
  cuvant = realloc(cuvant , dimensiune);
  cuvant[dimensiune-2] = a->litera;
  cuvant[dimensiune-1] = '\0';
//daca am gasit cuvant la acest pas afisam in fisier
  if(a->sfarsit_cuvant == 1)
      fprintf(out,"%s ",cuvant);

  int i=0;
  char *aux;
  //parcurgem recursiv pentru fii lui a(celula la care ne aflam)

  for(; i<a->nr_fii ; i++)
  {
    //cream o copie a lui aux pe care o vom da ca parametru pentru functia de mai jos
    aux=malloc(dimensiune);
    strcpy(aux,cuvant);
    afisare_cuvinte_de_la_o_celula_anume(out,a->fii[i],aux,dimensiune);

  }

}


//functia returneaza toate cuvintele din trie care inceput cu un prefix dat
//e o functie recursiva care construieste in stringul cuvant dat ca parametru
//litera cu litera cuvintele (celulele care au sfarsit_cuvant=1 si le afiseaza unul dupa altul)

void find_all_with_prefix(FILE *out,Trie *trie,char *cuvant,char *prefix)
{
  //daca prefix e null afisam toate cuvintele din arbore
    if( !prefix )
    {
        afisare_cuvinte_de_la_o_celula_anume(out,trie->celula,cuvant,0);
        fprintf(out, "\n");
        return;
    }
    //cautam prefixul dat in trie
    TCelula *aux = find_prefix(trie,prefix);
    //daca e null inseamna ca nu exista si deci nu exista nici cuvintele care sa inceapa cu el
    if( !aux )
    {
      fprintf(out,"None\n");
      return;
    }
    //altfel facem o copie a prefixuli si o trimitem mai departe
    //in functia afisare_cuvane_de_la_o_celula_anume

    cuvant = malloc(strlen(prefix)+1);
    strcpy(cuvant,prefix);
    afisare_cuvinte_de_la_o_celula_anume(out,aux,cuvant,strlen(prefix));
    fprintf(out, "\n");

}

//functie de tip void care ne va furniza suma si nr de elemente care incep de la o celula anume
//primita ca parametru.la inceput suma si nr sunt 0,dimensiunea este tot 0(tine cat de multe litere am
//inaintat de la celula data ca parametru),iar dimensiune_prefix va fi tinut pe post de strlen(prefix)
void mean_length(TCelula *celula,float *suma,int dimensiune,int dimensiune_prefix,int *nr)
{
if( !celula ) return;
//daca eavem cuvant marim suma si nr (nr de cuvinte de la celula data ca parametru)
if(celula->sfarsit_cuvant == 1)
{
  *suma = *suma + dimensiune + dimensiune_prefix;
  *nr = *nr+1;
}
int i;
//parcurgem recursiv pt fii,daca exista
for(i=0;i<celula->nr_fii;i++)
{
  mean_length(celula->fii[i],suma,dimensiune+1,dimensiune_prefix,nr);

}

}

//functie care sterge un cuvant din trie

void remove_celula(Trie *trie,char *cuvant)
{
  //cautam cuvantul in trie
  TCelula *aux = find_prefix(trie,cuvant);
  //daca cuvantul e null sau prefixul nu e gasit iesim din functie
  if( !cuvant || !aux )
      return;
  //altfel inseamna ca am gasit cuvantul.Marcam cu 0 sfarsit_cuvant
  aux->sfarsit_cuvant = 0;
  //parcurgem de jos in sus cat timp nu gasim o celula cu sfarsit_cuvant=1
  //si nr_fii==0
  while(aux&&aux->nr_fii == 0&&aux->sfarsit_cuvant==0)
  {

    TCelula *copie = aux;
    int j = 0;
    //cautam in vectorul de fii al lui aux->parinte indicele
    //la care se gaseste aux;
    for(j = 0; j<aux->parinte->nr_fii ; j++)
      if(copie->litera == aux->parinte->fii[j]->litera)
        break;
    int k;
    //translatam la stanga vectorul de fii de la pozitia j
    //ultimul din vectorul de fii va fi NULL(cel de pe pozitia nr_fii-1)
    //acutalizam aux->nr_fii--;
    for(k=j ; k<aux->parinte->nr_fii-1 ; k++)
      aux->parinte->fii[k] = aux->parinte->fii[k+1];
    //trebuie dealocat ultima "lista"
    aux->parinte->fii[aux->parinte->nr_fii-1] = NULL;
    aux->parinte->nr_fii--;
    aux = aux->parinte;

  }

}

//functie care cauta un element in trie si returneaza True sau False

void find(FILE *out,Trie *trie, char *element_cautat)
{
TCelula *aux=trie->celula;
int i=0,count=0;
//daca trie-ul e compus doar dintr-o celula(cea cu litera='\0') afisam False si iesim
if (!aux->fii)
{
  fprintf(out,"False\n");
  return;
}

//cautam litera cu litera in trie in functie de literele elementului_cautat dat ca parametru
  while(element_cautat[count]&&i<aux->nr_fii)
  {
    if(aux->fii[i]->litera==element_cautat[count])
    {
      aux=aux->fii[i];
      count++;
      i=0;
    }
    else
    {
      i++;

    }
  }
  //verificam daca am ajuns la sfarsitul cuvantului si afisam mesajul corespunzator

  if(aux->sfarsit_cuvant==1&&element_cautat[count]=='\0') fprintf(out,"True\n");
  else fprintf(out,"False\n");

}

//functie care returneaza cel mai mare cuvant cel mult egal cu un prefix dat
//sau None daca nu exista

void find_longest_prefix(FILE *out,Trie *trie,char *prefix)
{
//daca trie-ul e null sau prefixul e null afisam None si iesim din functie
  if(!trie||!prefix)
    {
      fprintf(out, "None\n");
      return;
    }

    TCelula *aux;
  int count=strlen(prefix);
  //apelam find_prefix pentru prefix cat timp nu il gasim in trie
  //si micsoram cu cate o litera prefixul la fiecare pas(punem '\0' la sfarsit)
  //count--;
  while(count>0)
  {
    aux=find_prefix(trie,prefix);
    //daca aux nu e null afisam litera cu litera prefixul;
    if(aux)
    {
      int i=0;
      for(;i<count;i++)
        fprintf(out,"%c",prefix[i]);

      fprintf(out,"\n");
      return;
    }
    else
    {
     count--;
     prefix[count]='\0';

    }
  }
//Altfel afisam None.
  fprintf(out, "None\n");
  return;


}



int main(int argc,char *argv[])

{
 FILE *in=fopen(argv[1],"r");
 FILE *out=fopen(argv[2],"w");
 Trie *trie=malloc(sizeof(Trie));
 Init_Trie(trie);



int nr_linii,i,c;
char *operatie=malloc(15),*string=NULL,*cuvant=malloc(15);
cuvant[0]='\0';

fscanf(in,"%d\n",&nr_linii);
TCelula *aux=NULL;

for(i=0;i<nr_linii;i++)
 {
    fscanf(in,"%s",operatie);
    int c,count = 0,ok=1;
    //citim caracter cu caracter si reallocam memorie pt string
    c= fgetc( in );

    if(c=='\n')
      {

        string=NULL;
        ok=0;
      }

    while(c==' ')
      c=fgetc(in);


    string=malloc(3000);
    while(ok==1&& c!= EOF && c != '\n'&&c!=' ')
    {


        string[count++]=c;
        //string=realloc(string,count);
        c= fgetc(in);
    }
    string[count]='\0';

    //printf("operatia este %s  ,iar cuvantul este %s\n",operatie,string);

    if(strcmp(operatie,"add")==0)
    {

      Insert(trie,string);

    }

    if(strcmp(operatie,"remove")==0)
    {

      remove_celula(trie,string);


    }

     if(strcmp(operatie,"find")==0)
    {

      find(out,trie,string);


    }

     if(strcmp(operatie,"find_longest_prefix")==0)
    {

      find_longest_prefix(out,trie,string);

    }

     if(strcmp(operatie,"find_all_with_prefix")==0)
    {

      find_all_with_prefix(out,trie,cuvant,string);


    }

    if(strcmp(operatie,"mean_length")==0)
    {

      float suma=0;
      int nr_elemente=0;

        if(!string)
      {
        //daca string e null inseamna ca calculam mean_length pentru tot trie-ul
        mean_length(trie->celula,&suma,0,0,&nr_elemente);
        //scadem trie->celula->nr_fii din suma pt ca suma va contine si litera
        //din trie->celula luata de trie->celula->nr fii ori
        suma=suma - trie->celula->nr_fii;
        fprintf(out, "%.3f\n",suma/nr_elemente);
        nr_elemente = 0;
        suma = 0;

      }
        //daca stringul nu e null
      else
      {

      aux = find_prefix(trie,string);
      //daca prefixul nu e gasit in trie afisam "0"
      if(!aux)
      {
        fprintf(out,"0\n");

      }


      else

      {
        //altfel apelam functia mean_length
        mean_length(aux,&suma,0,strlen(string),&nr_elemente);
        fprintf(out, "%.3f\n",suma/nr_elemente);
        nr_elemente=0;
        suma=0;
      }



    }
  }

    if(string)
      {
      free(string);
      string = NULL;

      }

   }

    fclose(in);
    fclose(out);

}





